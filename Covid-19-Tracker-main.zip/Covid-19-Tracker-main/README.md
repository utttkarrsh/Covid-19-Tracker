<p>
<h2>
Covid-19 StateWise Count India
</h2>
</p>
<p>
This is website which displays a realtime graph of covid19 statewise stats in India.<br>
  <b>Link to live website</b> <a href = "https://coronaindia19tracker.000webhostapp.com/">coronaindia19tracker.000webhostapp.com</a>
<ul>
<li><b>API used: </b><a href = "https://covid19india.org">covid19india.org</a></li>
<li><b>Chart library: </b><a href = "https://www.chartjs.org/">Chart.JS</a></li>
</ul>
<img src="https://github.com/lostmartian/Covid-19-Tracker/blob/master/feel.png" height=500 width=1200>
</p>

